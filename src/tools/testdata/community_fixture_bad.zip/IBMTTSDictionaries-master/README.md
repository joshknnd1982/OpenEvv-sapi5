Fixture for the community dictionary update tests.
